
        <!--=====================================
                    PRIVACY PART START
        =======================================-->
        <section class="inner-section privacy-part mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <ul class="nav nav-tabs">
                            <!--<li><a href="javascript:void(0)" class="tab-link active" data-bs-toggle="tab">descriptions</a></li>-->
                            <li>Privacy Policy</p></li>
                        </ul>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <?= $page->privacy_policy ?>
                    </div>
                </div>
            </div>
        </section>
        <!--=====================================
                    PRIVACY PART END
        =======================================-->