<?php

if(!isset($routes))
{ 
    $routes = \Config\Services::routes(true);
}

$routes->group('admin', ['namespace' => 'App\Modules\Admin\Controllers'], function ($routes) {
    $routes->add('/', 'Admin::index');
     $routes->add('get_admin_notifications', 'Admin::get_admin_notifications');
     $routes->add('update_admin_token', 'Admin::update_admin_token');

});