<?php

namespace App\Modules\Admin\Controllers;

use App\Controllers\BaseController;
use App\Models\CommonModel;
use App\Modules\Admin\Models\AdminModel;

class Admin extends BaseController
{

    public function __construct()
    {
        $this->CommonModel = new CommonModel;
        
        $session = session()->get('mySession');
        if($session == "")
        {
            header('location:/admin_login');
            exit();
        }
        
    }

    public function index()
    {
        $filter                 = array( 'id' => 1 );
        $data['setting']        = $this->CommonModel->get_single('setting',$filter);
        $data['page_title']     = "Dashboard";
        $data['page_headline']  = "Dashboard";

        echo view('App\Modules\Admin\Views\header', $data);
        echo view('App\Modules\Admin\Views\sidebar', $data);
        echo view('App\Modules\Admin\Views\index', $data);
        echo view('App\Modules\Admin\Views\footer', $data);
    }
    
    public function update_admin_token()
    {
        $token  =  $this->request->getVar('token');
        
        $update_data = array("token" => $token);
        $filter = array("id"=> 2);
        $update = $this->CommonModel->update_data("user",$update_data,$filter);
        
        if($update != false)
        {
            $val = ['status'        => '1','message'      => 'Token updated' ];
            echo json_encode($val);
            die;
        }
        else
        { 
            $val = ['status'        => '1','message'      => 'somthing went wrong' ];
            echo json_encode($val);
            die;
        }
    }
    
    // public function get_admin_notifications()
    // {

    //     $query              = "SELECT * FROM admin_notifications order by id desc limit 30";
    //     $exist = $this->CommonModel->custome_query($query);

    //     $data_array = array();
        
    //     $result_html = '';
        
    //     if(!empty($exist))
    //     {
    //         foreach ($exist as $row) 
    //         {
    //         $orgDate        = $row->created;  
    //             $result_html .= '<a href="javascript:void(0)" class="message-item">
                                    
    //                                 <div class="mail-contnet">
    //                                     <h5 class="message-title">'.$row->title.'</h5>
    //                                     <span class="mail-desc">'.$row->message.'</span>
    //                                     <span class="time">'.date("d-M-y h:i A", strtotime($orgDate)).'</span>
    //                                 </div>
    //                             </a>';
    //         }

    //         $val = ['status'        => '1','notifications'      => $result_html ];
    //         echo json_encode($val);
    //         die;
    //     } 
    //     else 
    //     {
    //         $data = ['status' => '0', 'query'         =>  $query, 'message' => 'No new notification found.'];
    //         echo json_encode($data);
    //         die;
    //     }
        
    // }
    
    public function get_admin_notifications()
    {

        $query              = "SELECT * FROM admin_notifications order by id desc limit 30";
        $exist = $this->CommonModel->custome_query($query);

        $data_array = array();
        
        $result_html = '';
        
        if(!empty($exist))
        {
            foreach ($exist as $row) 
            {
            $orgDate        = $row->created;  
                $result_html .= '<a href="javascript:void(0)" class="message-item">
                                    
                                    <div class="mail-contnet">
                                        <h5 class="message-title">'.$row->title.'</h5>
                                        <span class="mail-desc">'.$row->message.'</span>
                                        <span class="time">'.date("d-M-y h:i A", strtotime($orgDate)).'</span>
                                    </div>
                                </a>';
            }

            $val = ['status'        => '1','notifications'      => $result_html ];
            echo json_encode($val);
            die;
        } 
        else 
        {
            $data = ['status' => '0', 'query'         =>  $query, 'message' => 'No new notification found.'];
            echo json_encode($data);
            die;
        }
        
    }

}